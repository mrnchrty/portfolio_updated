function notFound(req, res, next) {
  res.status(404).json({ error: 'Endpoint not found.' });
}
function errorHandler(error, req, res, next) {
  console.error(error.message);
  const status = Number(error.status) || 500;
  res.status(status).json({ error: status === 500 ? 'Unexpected server error.' : error.message });
}
module.exports = { notFound, errorHandler };
