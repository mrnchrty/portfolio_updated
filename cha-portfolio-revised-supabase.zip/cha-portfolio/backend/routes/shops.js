const express = require('express');
const { listProducts, createOrder } = require('../controllers/shopController');
const router = express.Router();
router.get('/:slug/products', listProducts);
router.post('/:slug/orders', createOrder);
module.exports = router;
