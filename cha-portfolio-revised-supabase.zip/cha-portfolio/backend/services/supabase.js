const { createClient } = require('@supabase/supabase-js');
let client;
function getSupabase() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) {
    const error = new Error('Supabase is not configured. Copy .env.example to .env and add your existing project settings.');
    error.status = 503;
    throw error;
  }
  if (!client) client = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  return client;
}
module.exports = { getSupabase };
