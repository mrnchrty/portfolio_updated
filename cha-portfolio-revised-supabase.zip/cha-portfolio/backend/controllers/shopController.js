const { getSupabase } = require('../services/supabase');
const SHOP_SLUGS = new Set(['digicha', 'mochajaki']);

async function listProducts(req, res, next) {
  try {
    const slug = req.params.slug;
    if (!SHOP_SLUGS.has(slug)) return res.status(404).json({ error: 'Shop not found.' });
    const db = getSupabase();
    const { data: shop, error: shopError } = await db.from('shops').select('id,slug,name').eq('slug', slug).eq('is_active', true).single();
    if (shopError || !shop) return res.status(404).json({ error: 'Shop not found or inactive.' });
    const { data, error } = await db.from('products').select('id,shop_id,category_id,name,description,price,available,image_url,categories(name)').eq('shop_id', shop.id).order('created_at', { ascending: false });
    if (error) throw error;
    const products = (data || []).map(p => ({ ...p, category_name: p.categories?.name || null, categories: undefined, shop_slug: slug }));
    res.json({ shop, products });
  } catch (error) { next(error); }
}

async function createOrder(req, res, next) {
  try {
    const slug = req.params.slug;
    if (!SHOP_SLUGS.has(slug)) return res.status(404).json({ error: 'Shop not found.' });
    const { customerName, customerEmail, customerContact = '', customerAddress = '', items } = req.body || {};
    if (typeof customerName !== 'string' || customerName.trim().length < 2 || customerName.length > 120) return res.status(400).json({ error: 'Enter a valid customer name.' });
    if (typeof customerEmail !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerEmail) || customerEmail.length > 254) return res.status(400).json({ error: 'Enter a valid email address.' });
    if (typeof customerContact !== 'string' || customerContact.length > 40 || typeof customerAddress !== 'string' || customerAddress.length > 500) return res.status(400).json({ error: 'Contact or notes are too long.' });
    if (!Array.isArray(items) || items.length < 1 || items.length > 50) return res.status(400).json({ error: 'Your order must contain 1 to 50 line items.' });
    const normalized = new Map();
    for (const item of items) {
      const productId = String(item.productId || '');
      const quantity = Number(item.quantity);
      if (!productId || !Number.isInteger(quantity) || quantity < 1 || quantity > 99) return res.status(400).json({ error: 'Each item needs a valid product ID and quantity from 1 to 99.' });
      normalized.set(productId, (normalized.get(productId) || 0) + quantity);
    }
    const db = getSupabase();
    const { data: shop, error: shopError } = await db.from('shops').select('id,slug,name').eq('slug', slug).eq('is_active', true).single();
    if (shopError || !shop) return res.status(404).json({ error: 'Shop not found or inactive.' });
    const ids = [...normalized.keys()];
    const { data: products, error: productError } = await db.from('products').select('id,shop_id,name,description,price,available,image_url').in('id', ids);
    if (productError) throw productError;
    if (!products || products.length !== ids.length) return res.status(400).json({ error: 'One or more products no longer exist. Refresh the catalog.' });
    const productMap = new Map(products.map(p => [String(p.id), p]));
    const orderItems = [];
    let total = 0;
    for (const [id, quantity] of normalized.entries()) {
      const product = productMap.get(id);
      if (!product || product.shop_id !== shop.id) return res.status(400).json({ error: 'Cross-store orders are not allowed.' });
      if (!product.available) return res.status(409).json({ error: `${product.name} is unavailable.` });
      const price = Number(product.price);
      total += price * quantity;
      orderItems.push({ product_id: product.id, product_name: product.name, unit_price: price, quantity, line_total: price * quantity });
    }
    // Supabase/PostgREST calls do not provide multi-table transactions across independent requests.
    // The database RPC below creates the order and all line items atomically in one transaction.
    const { data, error } = await db.rpc('create_shop_order', {
      p_shop_id: shop.id,
      p_customer_name: customerName.trim(),
      p_customer_email: customerEmail.trim().toLowerCase(),
      p_customer_contact: customerContact.trim(),
      p_customer_address: customerAddress.trim(),
      p_items: orderItems
    });
    if (error) throw error;
    const order = Array.isArray(data) ? data[0] : data;
    res.status(201).json({ order: { id: order.id, order_number: order.order_number, total: Number(order.total), status: order.status }, message: 'Order saved. No payment has been collected.' });
  } catch (error) { next(error); }
}
module.exports = { listProducts, createOrder };
