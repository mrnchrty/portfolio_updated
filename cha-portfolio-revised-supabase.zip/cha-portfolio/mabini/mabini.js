const placeFilter = document.getElementById('place-filter');
placeFilter.addEventListener('change', () => {
  document.querySelectorAll('#places [data-type]').forEach(card => {
    card.hidden = placeFilter.value !== 'all' && card.dataset.type !== placeFilter.value;
  });
});
