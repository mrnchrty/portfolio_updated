(() => {
 const lightbox=document.getElementById('lightbox');const preview=lightbox.querySelector('img');
 function openPreview(img){preview.src=img.src;preview.alt=img.alt;lightbox.hidden=false;document.querySelector('.lightbox-close').focus()}
 function closePreview(){lightbox.hidden=true;preview.src=''}
 document.querySelectorAll('.zoomable').forEach(img=>{img.addEventListener('click',()=>openPreview(img));img.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openPreview(img)}})});
 document.querySelector('.lightbox-close').addEventListener('click',closePreview);lightbox.addEventListener('click',e=>{if(e.target===lightbox)closePreview()});document.addEventListener('keydown',e=>{if(e.key==='Escape')closePreview()});
 document.querySelectorAll('.work-card').forEach(card=>{card.addEventListener('click',e=>{if(e.target.closest('a'))return;if(matchMedia('(hover: none)').matches)card.classList.toggle('is-open')});card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){if(e.target===card){e.preventDefault();card.classList.toggle('is-open')}}})});
})();
