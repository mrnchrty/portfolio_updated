(() => {
const shop = document.querySelector('[data-shop]').dataset.shop;
const cartKey = `cha-portfolio-cart-${shop}`;
const apiBase = '/api';
const fallbackProducts = [
 {id:'sample-mochajaki-1',shop_slug:shop,name:'Iced Coffee',description:'Smooth coffee served chilled over ice.',price:89.00,available:true,category_name:'Beverages',image_url:'../assets/images/mocha-iced-coffee.svg',is_sample:true},
 {id:'sample-mochajaki-2',shop_slug:shop,name:'Iced Mocha',description:'Coffee, milk, and chocolate in one cup.',price:109.00,available:true,category_name:'Beverages',image_url:'../assets/images/mocha-iced-mocha.svg',is_sample:true},
 {id:'sample-mochajaki-3',shop_slug:shop,name:'Caramel Latte',description:'Creamy latte with a caramel swirl.',price:119.00,available:true,category_name:'Beverages',image_url:'../assets/images/mocha-caramel-latte.svg',is_sample:true},
 {id:'sample-mochajaki-4',shop_slug:shop,name:'Chocolate Frappe',description:'A cold, chocolatey blended treat.',price:129.00,available:true,category_name:'Beverages',image_url:'../assets/images/mocha-chocolate-frappe.svg',is_sample:true},
 {id:'sample-mochajaki-5',shop_slug:shop,name:'Strawberry Milk',description:'Sweet strawberry milk with fruity flavor.',price:99.00,available:true,category_name:'Beverages',image_url:'../assets/images/mocha-strawberry-milk.svg',is_sample:true},
 {id:'sample-mochajaki-6',shop_slug:shop,name:'Chocolate Chip Cookies',description:'Golden cookies with chocolate chips.',price:45.00,available:true,category_name:'Baked Goods',image_url:'../assets/images/mocha-cookies.svg',is_sample:true}
];
let products = [];
let cart = loadCart();
const productGrid = document.getElementById('product-grid');
const cartItems = document.getElementById('cart-items');
const status = document.getElementById('store-status');
const fmt = amount => new Intl.NumberFormat('en-PH',{style:'currency',currency:'PHP'}).format(Number(amount)||0);
function loadCart(){try{return JSON.parse(localStorage.getItem(cartKey)||'[]')}catch{return []}}
function saveCart(){localStorage.setItem(cartKey,JSON.stringify(cart));renderCart();updateCount();}
function updateCount(){document.getElementById('cart-count').textContent=cart.reduce((n,item)=>n+item.quantity,0)}
function escapeHtml(value){return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function imageFor(product){return product.image_url || (shop==='digicha'?'../assets/images/digital-placeholder.svg':'../assets/images/food-placeholder.svg')}
function renderProducts(){
 const term=document.getElementById('product-search').value.toLowerCase().trim();
 const category=document.getElementById('category-filter').value;
 const list=products.filter(p=>(p.name+' '+p.description+' '+(p.category_name||'')).toLowerCase().includes(term)&&(category==='all'||p.category_name===category));
 productGrid.innerHTML='';
 list.forEach(p=>{
  const card=document.createElement('article');card.className='card glass product-card reveal';
  card.innerHTML=`<img class="card-image" src="${escapeHtml(imageFor(p))}" alt="${escapeHtml(p.name)}"><div>${p.is_sample?'<span class="sample-label">SAMPLE DATA</span>':''}<h3>${escapeHtml(p.name)}</h3><p class="description">${escapeHtml(p.description)}</p><p class="${p.available?'stock':'stock out'}">${p.available?'Available':'Currently unavailable'}</p></div><div class="product-bottom"><span class="price">${fmt(p.price)}</span><button class="button small add-cart" type="button" ${p.available?'':'disabled'} data-id="${escapeHtml(p.id)}">Add to cart</button></div>`;
  productGrid.append(card);
 });
 document.getElementById('no-products').hidden=list.length>0;
 productGrid.querySelectorAll('.add-cart').forEach(btn=>btn.addEventListener('click',()=>addToCart(btn.dataset.id)));
}
function refreshCategories(){
 const select=document.getElementById('category-filter');const current=select.value;
 select.innerHTML='<option value="all">All categories</option>';
 [...new Set(products.map(p=>p.category_name).filter(Boolean))].sort().forEach(cat=>{const opt=document.createElement('option');opt.value=cat;opt.textContent=cat;select.append(opt)});
 select.value=[...select.options].some(o=>o.value===current)?current:'all';
}
function addToCart(id){
 const p=products.find(item=>String(item.id)===String(id));if(!p||!p.available)return;
 const found=cart.find(item=>String(item.id)===String(id));
 if(found)found.quantity=Math.min(99,found.quantity+1);else cart.push({id:p.id, name:p.name, price:Number(p.price), image_url:imageFor(p), quantity:1, is_sample:!!p.is_sample});
 saveCart();document.getElementById('cart-section').scrollIntoView({behavior:'smooth'});
}
function renderCart(){
 if(!cart.length){cartItems.innerHTML='<p class="empty-state">Your cart is empty. Add an item above to get started.</p>';}
 else{
  cartItems.innerHTML='';
  cart.forEach(item=>{
   const line=document.createElement('article');line.className='cart-line glass';
   line.innerHTML=`<img src="${escapeHtml(item.image_url)}" alt=""><div><h4>${escapeHtml(item.name)}</h4><p>${fmt(item.price)} each</p><div class="cart-controls"><button class="qty-btn" type="button" aria-label="Decrease quantity" data-action="minus" data-id="${escapeHtml(item.id)}">−</button><span>${item.quantity}</span><button class="qty-btn" type="button" aria-label="Increase quantity" data-action="plus" data-id="${escapeHtml(item.id)}">+</button><button class="button ghost small" type="button" data-action="remove" data-id="${escapeHtml(item.id)}">Remove</button></div></div><strong class="line-price">${fmt(item.price*item.quantity)}</strong>`;
   cartItems.append(line);
  });
 }
 cartItems.querySelectorAll('[data-action]').forEach(btn=>btn.addEventListener('click',()=>{
  const item=cart.find(p=>String(p.id)===btn.dataset.id);if(!item)return;
  if(btn.dataset.action==='remove')cart=cart.filter(p=>String(p.id)!==btn.dataset.id);
  if(btn.dataset.action==='minus')item.quantity=Math.max(1,item.quantity-1);
  if(btn.dataset.action==='plus')item.quantity=Math.min(99,item.quantity+1);
  saveCart();
 }));
 const subtotal=cart.reduce((sum,item)=>sum+item.price*item.quantity,0);
 document.getElementById('cart-subtotal').textContent=fmt(subtotal);
 const review=document.getElementById('checkout-review');
 review.innerHTML=cart.length?cart.map(item=>`<div class="total-row"><span>${escapeHtml(item.name)} × ${item.quantity}</span><strong>${fmt(item.price*item.quantity)}</strong></div>`).join('')+`<div class="total-row final"><span>Total</span><strong>${fmt(subtotal)}</strong></div>`:'<p class="muted">Your cart is empty.</p>';
 updateCount();
}
async function loadProducts(){
 try{
  const response=await fetch(`${apiBase}/shops/${shop}/products`);
  if(!response.ok)throw new Error('Backend not configured');
  const data=await response.json();
  if(!Array.isArray(data.products))throw new Error('Unexpected product response');
  products=data.products;
  document.getElementById('mode-label').textContent='Connected catalog';
  status.textContent='Products loaded from the configured backend. Check product details and availability before ordering.';
 }catch(error){
  products=fallbackProducts;
  document.getElementById('mode-label').textContent='Demo catalog';
  status.textContent='You are browsing the sample catalog. Prices and product illustrations are for this portfolio demo; no real orders or payments are processed.';
 }
 refreshCategories();renderProducts();renderCart();
}
document.getElementById('product-search').addEventListener('input',renderProducts);
document.getElementById('category-filter').addEventListener('change',renderProducts);
document.getElementById('open-cart').addEventListener('click',()=>document.getElementById('cart-section').scrollIntoView({behavior:'smooth'}));
document.getElementById('checkout-button').addEventListener('click',()=>document.getElementById('checkout').scrollIntoView({behavior:'smooth'}));
document.getElementById('clear-cart').addEventListener('click',()=>{cart=[];saveCart()});
document.getElementById('checkout-form').addEventListener('submit',async event=>{
 event.preventDefault();
 const message=document.getElementById('checkout-message');
 if(!cart.length){message.className='notice error';message.textContent='Your cart is empty.';return;}
 if(cart.some(item=>item.is_sample)){message.className='notice error';message.textContent='This cart contains sample demonstration items. Configure the database and add real products before creating an order.';return;}
 const form=new FormData(event.currentTarget);
 const payload={customerName:form.get('customerName'),customerEmail:form.get('customerEmail'),customerContact:form.get('customerContact'),customerAddress:form.get('customerAddress'),items:cart.map(item=>({productId:item.id,quantity:item.quantity}))};
 const button=document.getElementById('place-order');button.disabled=true;button.textContent='Submitting…';
 try{
  const response=await fetch(`${apiBase}/shops/${shop}/orders`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const data=await response.json();
  if(!response.ok)throw new Error(data.error||'Order could not be submitted.');
  message.className='notice success';message.textContent=`Order received. Reference: ${data.order.order_number}. This is not a payment confirmation.`;
  cart=[];saveCart();event.currentTarget.reset();
 }catch(error){
  message.className='notice error';message.textContent=`Could not save the order: ${error.message}. Confirm backend and Supabase configuration.`;
 }finally{button.disabled=false;button.textContent='Place order';}
});
loadProducts();
})();
