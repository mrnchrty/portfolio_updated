const download = document.getElementById('resume-download');
const note = document.getElementById('resume-note');
download?.addEventListener('click', event => {
  // The browser handles the actual download; this message helps when the file is not installed yet.
  fetch(download.href, {method:'HEAD'}).then(response => {
    if (!response.ok) note.textContent = 'Résumé PDF not found yet. Place your actual file at assets/documents/cha-resume.pdf.';
  }).catch(() => { note.textContent = 'If the download does not start, confirm that assets/documents/cha-resume.pdf exists.'; });
});
