-- Clearly labeled demonstration catalog. Replace these rows with your actual products and prices.
insert into public.shops (slug, name, description) values
('digicha', 'DigiCha', 'Creative products, design-related items, and digital products.'),
('mochajaki', 'Mochajaki', 'Food and beverage storefront.')
on conflict (slug) do update set name = excluded.name, description = excluded.description;

insert into public.categories (shop_id, name, slug)
select s.id, c.name, c.slug from public.shops s
cross join (values
 ('digicha','Digital Products','digital-products'),
 ('digicha','Design Templates','design-templates'),
 ('digicha','Creative Goods','creative-goods'),
 ('mochajaki','Pasta and Meals','pasta-and-meals'),
 ('mochajaki','Baked Lasagna','baked-lasagna'),
 ('mochajaki','Baked Goods','baked-goods'),
 ('mochajaki','Desserts','desserts'),
 ('mochajaki','Beverages','beverages')
) as c(shop_slug,name,slug)
where s.slug = c.shop_slug
on conflict (shop_id, slug) do nothing;

insert into public.products (shop_id, category_id, name, description, price, available, image_url, is_sample)
select s.id, c.id, p.name, p.description, p.price, true, p.image_url, true
from (values
 ('digicha','digital-products','Digital Planner','Plan your week beautifully.',149.00,'../assets/images/digi-planner.svg'),
 ('digicha','design-templates','Resume Template','A polished, editable CV layout.',99.00,'../assets/images/digi-resume.svg'),
 ('digicha','digital-products','Study Notes Template','Clean pages for your study sessions.',79.00,'../assets/images/digi-study-notes.svg'),
 ('digicha','design-templates','Social Media Template Bundle','Coordinated post and story layouts.',199.00,'../assets/images/digi-social-bundle.svg'),
 ('digicha','digital-products','Budget Tracker Spreadsheet','Track spending, savings, and goals.',129.00,'../assets/images/digi-budget-tracker.svg'),
 ('digicha','creative-goods','Digital Sticker Pack','Cute stickers for digital journals.',59.00,'../assets/images/digi-stickers.svg'),
 ('mochajaki','beverages','Iced Coffee','Smooth coffee served chilled over ice.',89.00,'../assets/images/mocha-iced-coffee.svg'),
 ('mochajaki','beverages','Iced Mocha','Coffee, milk, and chocolate in one cup.',109.00,'../assets/images/mocha-iced-mocha.svg'),
 ('mochajaki','beverages','Caramel Latte','Creamy latte with a caramel swirl.',119.00,'../assets/images/mocha-caramel-latte.svg'),
 ('mochajaki','beverages','Chocolate Frappe','A cold, chocolatey blended treat.',129.00,'../assets/images/mocha-chocolate-frappe.svg'),
 ('mochajaki','beverages','Strawberry Milk','Sweet strawberry milk with fruity flavor.',99.00,'../assets/images/mocha-strawberry-milk.svg'),
 ('mochajaki','baked-goods','Chocolate Chip Cookies','Golden cookies with chocolate chips.',45.00,'../assets/images/mocha-cookies.svg')
) as p(shop_slug,category_slug,name,description,price,image_url)
join public.shops s on s.slug=p.shop_slug
join public.categories c on c.shop_id=s.id and c.slug=p.category_slug
where not exists (select 1 from public.products old where old.shop_id=s.id and old.name=p.name);
