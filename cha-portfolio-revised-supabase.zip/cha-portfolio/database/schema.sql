-- Cha Portfolio shops database schema for Supabase PostgreSQL.
-- Run this script in Supabase SQL Editor. Do not expose the service-role key in frontend code.
create extension if not exists pgcrypto;

create table if not exists public.shops (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug in ('digicha', 'mochajaki')),
  name text not null,
  description text not null default '',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  name text not null,
  slug text not null,
  created_at timestamptz not null default now(),
  unique (shop_id, slug),
  unique (shop_id, name)
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  category_id uuid references public.categories(id) on delete set null,
  name text not null,
  description text not null default '',
  price numeric(12,2) not null check (price >= 0),
  available boolean not null default true,
  image_url text,
  is_sample boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists products_shop_available_idx on public.products(shop_id, available);
create index if not exists products_category_idx on public.products(category_id);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique default ('CHA-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10))),
  shop_id uuid not null references public.shops(id),
  customer_name text not null,
  customer_email text not null,
  customer_contact text not null default '',
  customer_address text not null default '',
  subtotal numeric(12,2) not null check (subtotal >= 0),
  total numeric(12,2) not null check (total >= 0),
  status text not null default 'received' check (status in ('received','processing','completed','cancelled')),
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid','pending','paid','failed','refunded')),
  created_at timestamptz not null default now()
);
create index if not exists orders_shop_created_idx on public.orders(shop_id, created_at desc);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  unit_price numeric(12,2) not null check (unit_price >= 0),
  quantity integer not null check (quantity between 1 and 99),
  line_total numeric(12,2) not null check (line_total >= 0)
);
create index if not exists order_items_order_idx on public.order_items(order_id);

-- Atomically create order + items in one PostgreSQL transaction.
create or replace function public.create_shop_order(
  p_shop_id uuid,
  p_customer_name text,
  p_customer_email text,
  p_customer_contact text,
  p_customer_address text,
  p_items jsonb
) returns table(id uuid, order_number text, total numeric, status text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_order_id uuid;
  v_order_number text;
  v_total numeric(12,2) := 0;
  v_item jsonb;
begin
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) < 1 then
    raise exception 'Order must include at least one item';
  end if;

  -- Recheck availability, ownership, and prices in the database transaction.
  for v_item in select value from jsonb_array_elements(p_items)
  loop
    if not exists (
      select 1 from products p
      where p.id = (v_item->>'product_id')::uuid
        and p.shop_id = p_shop_id
        and p.available = true
    ) then
      raise exception 'Product is unavailable or does not belong to this shop';
    end if;
    v_total := v_total + (
      select p.price * (v_item->>'quantity')::integer
      from products p
      where p.id = (v_item->>'product_id')::uuid
        and p.shop_id = p_shop_id
        and p.available = true
    );
  end loop;

  insert into orders(shop_id, customer_name, customer_email, customer_contact, customer_address, subtotal, total)
  values (p_shop_id, p_customer_name, p_customer_email, coalesce(p_customer_contact,''), coalesce(p_customer_address,''), v_total, v_total)
  returning orders.id, orders.order_number into v_order_id, v_order_number;

  for v_item in select value from jsonb_array_elements(p_items)
  loop
    insert into order_items(order_id, product_id, product_name, unit_price, quantity, line_total)
    select v_order_id, p.id, p.name, p.price, (v_item->>'quantity')::integer, p.price * (v_item->>'quantity')::integer
    from products p
    where p.id = (v_item->>'product_id')::uuid
      and p.shop_id = p_shop_id and p.available = true;
  end loop;

  return query select o.id, o.order_number, o.total, o.status from orders o where o.id = v_order_id;
end;
$$;

-- Public reads are mediated by Express using the server-only key. Block direct anonymous table access.
alter table public.shops enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
revoke all on public.shops, public.categories, public.products, public.orders, public.order_items from anon, authenticated;
revoke execute on function public.create_shop_order(uuid,text,text,text,text,jsonb) from public, anon, authenticated;
grant execute on function public.create_shop_order(uuid,text,text,text,text,jsonb) to service_role;
