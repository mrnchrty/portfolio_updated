# Cha Portfolio

A responsive personal portfolio and two separate storefronts for DigiCha and Mochajaki. Built with semantic HTML5, CSS3, Vanilla JavaScript, Node.js, Express, and Supabase PostgreSQL.

## Included pages

- **Home** — intro, featured projects, skills, Mabini preview, and shop links.
- **About Me** — academic background, leadership, interests, and image gallery.
- **Resume** — education, leadership, projects, and a PDF download placeholder.
- **Projects** — searchable/filterable galleries with an image lightbox.
- **Discover Mabini** — categorized local-photo showcase.
- **Shops** — directory for two distinct stores.
- **DigiCha** — separate creative/digital storefront with independent cart and checkout.
- **Mochajaki** — separate food and beverage storefront with independent cart and checkout.

## Technology

- HTML5, CSS3, Vanilla JavaScript
- Node.js 18+ and Express.js
- Supabase PostgreSQL
- Lucide/brand icon use can be added as needed; the initial interface uses lightweight typographic decorative marks and no invented social profile links.

## Folder structure

`index.html` is the only homepage file and is located at the project root. Homepage styling and interactions are in `home/home.css` and `home/home.js`. Other pages keep their own HTML/CSS/JS files. Shared styles and behavior live in `shared/`. The Express app is in `backend/`; SQL scripts are in `database/`.

## Requirements

- Node.js 18 or newer
- npm
- An existing Supabase project
- Visual Studio Code (recommended)

## Run locally

1. Extract `cha-portfolio.zip`.
2. Open the `cha-portfolio` folder in VS Code.
3. Open a terminal and install backend dependencies:

   ```bash
   cd backend
   npm install
   ```

4. Copy the environment example file:
   - Windows PowerShell: `Copy-Item .env.example .env`
   - macOS/Linux: `cp .env.example .env`

5. Edit `backend/.env` and enter your existing Supabase project URL and **server-only service-role key**. Do not share this file or commit it to version control. Do not put the service-role key in frontend JavaScript.
6. In Supabase, open **SQL Editor** and run `database/schema.sql`, followed by `database/seed.sql`. The seed catalog is demonstration data and must be replaced with real products/prices before accepting real orders.
7. Start the app from the `backend` directory:

   ```bash
   npm start
   ```

8. Open `http://localhost:3000` in your browser. The health endpoint is `http://localhost:3000/api/health`.

For development with Node's watch mode, use `npm run dev`.

## Supabase configuration and security

The Express server reads `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` from `backend/.env`. The secret key is only used by the server. The SQL schema enables Row Level Security and revokes direct table access from anonymous/authenticated roles; browser requests go through Express. Keep the server protected and do not deploy an unauthenticated order API publicly without adding rate limiting, abuse protection, and any business-specific order verification you need.

The database function `create_shop_order` stores the order and its line items atomically. It recalculates the total from current database prices, checks product availability and shop ownership, and snapshots product names/prices into each order item. The application rejects products from the other storefront. No payment provider is configured; orders are marked `unpaid` and the UI explicitly says no payment was collected.

## Images and documents

All static portfolio images are ordinary `<img>` elements directly in HTML. Placeholder SVGs are in `assets/images/` and can be replaced with your own photos/artwork. To update an image, place your image in `assets/images/` and edit the relevant HTML `src` attribute. For pages inside a folder, paths typically begin with `../assets/images/`.

Product images are database-driven through the `products.image_url` field. Upload a product image to a public Supabase Storage bucket (or another URL you control), then update that product row's `image_url`. Keep the URL stable and make sure it is allowed for public viewing if the storefront is public.

For your résumé PDF, put your actual file at `assets/documents/cha-resume.pdf`. Until that file exists, the download link is only a placeholder. No real résumé PDF was included in the supplied files.

## Updating the content

- **Colors and fonts:** edit CSS variables near the top of `shared/common.css`; each shop has a small brand-specific override in its own stylesheet.
- **Personal bio and leadership:** edit the page HTML directly. Verify dates and wording before public release.
- **Social media:** add only your real profile URLs; none were supplied, so no fabricated links are included.
- **Products:** edit the product rows in Supabase. Use `shop_id` to keep the two stores separate, and set real prices/availability only after confirming them.
- **Categories:** create categories with the correct `shop_id` and a unique slug for that store.
- **Shop banners and photos:** replace the placeholder images and keep descriptive `alt` text.
- **Mabini content:** add real photos and verify the place names and visitor information before publishing.
- **Certificates:** add only certificates you have actually earned.

## API endpoints

- `GET /api/health` — service status and whether environment variables exist.
- `GET /api/shops/:slug/products` — active shop's products.
- `POST /api/shops/:slug/orders` — validated order creation. Accepted slugs are `digicha` and `mochajaki`.

The order endpoint accepts a customer name, email, optional contact and address/notes, and line items containing `productId` and `quantity`. The backend ignores browser prices and reloads prices from Supabase. It prevents cross-store orders and uses a database RPC for atomic order creation.

## Troubleshooting

- **“Supabase is not configured”:** confirm `.env` is in `backend/`, names match `.env.example`, and restart the server.
- **Product list falls back to demo mode:** confirm the server is running at port 3000, the SQL scripts completed, and the shop rows exist.
- **Images do not load:** check relative paths from the page's folder and confirm the file exists under `assets/images/`.
- **Order creation fails:** check server logs, Supabase credentials, the schema/RPC, and product availability. Sample demo products are intentionally blocked from order submission.
- **Port 3000 is busy:** set `PORT=3001` in `.env`, then open `http://localhost:3001`.

## Current limitations and pre-publish checklist

- The supplied PDF reference has been used for content direction, but the provided PDF does not supply usable original image files for the project assets. Included SVGs are labeled placeholders.
- No actual résumé PDF, project screenshots, certificate scans, shop product photographs, social links, real product listings/prices, or payment-provider credentials were supplied.
- Checkout is a demonstration order workflow; there is no payment gateway, automatic digital delivery, shipping-fee calculation, or customer account system.
- The app has not been connected to your Supabase project because its configuration was not included. Run the SQL scripts and configure `.env` to test persistence end-to-end.
- Before public deployment, add rate limiting, abuse prevention, an order-management workflow, and privacy notice appropriate to the customer information collected.

## Shop demo catalog

DigiCha and Mochajaki each include six sample products with PHP prices and separate original SVG product illustrations. These are portfolio/demo listings, not a claim that either storefront is currently selling real goods. Update the sample catalog and image paths before accepting real orders. The same sample products are represented in the front-end fallback data and `database/seed.sql`.


## Supabase-first setup (revised)

The shop API uses Supabase PostgreSQL through the Node/Express backend. Never put the Supabase service-role key in browser JavaScript or commit `.env`.

1. Create a Supabase project.
2. In Supabase SQL Editor, run `database/schema.sql`, then `database/seed.sql` if you want the supplied demo catalog.
3. Copy `backend/.env.example` to `backend/.env` and set `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `PORT`, and `FRONTEND_ORIGIN`. Keep the service-role key server-side only.
4. In `backend/`, run `npm install`, then `npm start`. Open `http://localhost:3000`.
5. `/api/health` reports whether the server sees Supabase configuration; it does not guarantee schema setup.

### Replace your own images

The portfolio references clearly named files under `images/` for personal content: `images/meditrack.png`, `images/e-gasang.png`, `images/publication-01.jpg` through `publication-03.jpg`, `images/certificate-01.jpg` through `certificate-03.jpg`, and `images/writing-01.jpg` through `writing-03.jpg`. Create the `images` folder in the project root and add your own real images. These paths are placeholders, not fabricated samples. Replace `assets/images/cha-profile-placeholder.svg` with your profile photo path in HTML when ready. Keep image proportions intact; project screenshots are landscape and certificates should use `object-fit: contain`.

### Known limitations to configure before production

- The shop order endpoint persists orders and line items only when Supabase is configured. Demo catalog items are intentionally blocked from order submission.
- No real payment provider is configured. Orders explicitly state that payment has not been collected; do not treat this as a payment gateway.
- Supabase Auth customer accounts, per-customer order history, promotion redemption, and staff administration need credentials and the additional policies/API endpoints to be enabled before production use. Do not advertise them as live until tested.
- Article/project links and social account URLs are not invented. Add only real URLs.
